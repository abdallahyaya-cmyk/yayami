---
name: Sahel Sentinel
colors:
  surface: '#f6fafe'
  surface-dim: '#d6dade'
  surface-bright: '#f6fafe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4f8'
  surface-container: '#eaeef2'
  surface-container-high: '#e4e9ed'
  surface-container-highest: '#dfe3e7'
  on-surface: '#171c1f'
  on-surface-variant: '#3e4943'
  inverse-surface: '#2c3134'
  inverse-on-surface: '#edf1f5'
  outline: '#6e7a73'
  outline-variant: '#bdc9c1'
  surface-tint: '#006c4e'
  primary: '#005d42'
  on-primary: '#ffffff'
  primary-container: '#047857'
  on-primary-container: '#9ffdd3'
  inverse-primary: '#7bd8b1'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#005d3e'
  on-tertiary: '#ffffff'
  tertiary-container: '#007852'
  on-tertiary-container: '#8fffc9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#97f5cc'
  primary-fixed-dim: '#7bd8b1'
  on-primary-fixed: '#002115'
  on-primary-fixed-variant: '#00513a'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f6fafe'
  on-background: '#171c1f'
  surface-variant: '#dfe3e7'
  status-warning: '#dc2626'
  status-success-bg: '#dcfce7'
  ussd-screen-bg: '#059669'
  police-accent: '#334155'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  ussd-mono:
    fontFamily: courierPrime
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-mobile: 1rem
  margin-desktop: 1.5rem
  gutter: 1rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 1.5rem
---

## Brand & Style

The design system is engineered for **N'Djamena Trafik**, a critical infrastructure application designed to bridge the gap between high-end smartphones and low-connectivity environments. The brand personality is **Pragmatic, Resilient, and Authoritative**, evoking a sense of institutional trust and modern civic duty.

The visual style follows a **Corporate / Modern** approach with **Tactile Utility** elements. It prioritizes clarity and high contrast to ensure readability under direct sunlight and high-stress situations. The design features a dual-interface logic:
- **Police Panel:** Highly structured, data-dense, and utilitarian.
- **Citizen Interface:** Simplified, high-contrast, and "offline-aware," using physical metaphors to signify reliability.

The overall aesthetic uses deep slates and professional emeralds to differentiate itself from generic consumer apps, leaning into a "government-grade" feel that is both sophisticated and accessible.

## Colors

The palette is anchored by **Emerald Green (#047857)**, representing authority and "go" signals, modernized by **Deep Slate (#1e293b)** for high-contrast typography and primary actions.

- **Primary Emerald:** Used for headers, brand identity, and active navigation. It signifies the official nature of the app.
- **Deep Slate:** Used for the heaviest UI elements (buttons, primary headers) to provide a grounded, high-trust feel.
- **Surface Neutrals:** A range of slates from `#f1f5f9` (backgrounds) to `#ffffff` (interactive cards) ensures a clean, layered hierarchy.
- **Status Colors:** Use high-saturation reds for "Issue Fine" actions to prevent accidental taps, and soft greens for success confirmations to provide clear feedback in noisy environments.

## Typography

The design system utilizes **Inter** as its primary typeface due to its exceptional legibility and neutral, professional character. 

- **Hierarchy:** Headlines are strictly bold to emphasize the authoritative tone. Body text remains at a comfortable `14px` base to balance information density with readability.
- **USSD / Technical:** For the offline-first simulation or technical data readouts, use a monospaced font (**Courier Prime**) to signal a shift from the modern UI to legacy system communication.
- **Micro-copy:** Small labels (`label-sm`) use increased letter-spacing and uppercase styling when used for secondary metadata to ensure they don't get lost in complex forms.

## Layout & Spacing

This design system uses a **Fluid Grid** for mobile-first delivery, with a constrained `max-width` of 480px for tablet/desktop viewing to maintain the "handheld utility" feel.

- **Baseline:** A 4px grid system governs all spacing. 
- **The Stack:** Elements are vertically stacked using `16px` (stack-md) as the default gap between cards and sections. 
- **Margins:** A consistent `16px` safe area is maintained around all screens.
- **Reflow:** On wider screens, forms may transition from a single-column layout to a two-column layout for the Police Panel to improve data entry speed, while the Citizen Interface remains a focused, single-column experience.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layering** and **Subtle Outer Shadows**. 

- **Surface Tiers:** The background uses a soft slate (`#f1f5f9`), while active content sits on pure white (`#ffffff`) cards.
- **Shadows:** Use a single, consistent shadow style: `0 4px 6px -1px rgb(0 0 0 / 0.1)`. This provides enough lift to indicate interactable surfaces without feeling "floaty" or delicate.
- **Tactile Recess:** For input fields and "offline" screen simulations, use a subtle `inner-shadow` or a `1px` inset border to suggest a physical, durable tool that has been "carved" into the device.
- **Police Panel Depth:** Use flat borders (`1px solid #e2e8f0`) instead of shadows for data tables to maximize space and maintain a serious, institutional tone.

## Shapes

The shape language is **Rounded**, striking a balance between modern friendliness and professional structure.

- **Primary Elements:** Buttons and Input fields use a `0.5rem` (8px) radius. This provides a soft enough touch for citizens while remaining sharp enough for an official police application.
- **Container Level:** Large cards and the main app container use `1rem` (16px) or larger to create a distinct "app-within-an-app" look on larger screens.
- **Indicators:** Small status chips and tags use a full pill-shape (`rounded-full`) to differentiate them from interactive buttons.

## Components

### Buttons
- **Primary Action:** Solid Deep Slate background with white text. High-contrast and robust.
- **Secondary Action:** Transparent with a 1px Slate border.
- **Destructive (Fine Issuance):** Solid Red (`#dc2626`) with a slight darkening on press. This button should be physically larger than others to ensure ease of use for officers in the field.

### Input Fields
- **High-Contrast Design:** Pure white background with a `1px` Slate-300 border. On focus, the border thickens and changes to Emerald Green.
- **Labels:** Always persistent above the field; never use placeholder-only labels to ensure accessibility.

### Cards
- White backgrounds with soft 8px corners. 
- Include a 1px Slate-200 border for definition on light backgrounds.

### Status Indicators (Offline-First)
- **Connectivity Chip:** A persistent indicator in the header. Emerald for "Online," Amber for "Slow/USSD Mode," and Slate-400 for "Offline."
- **Sync Badge:** Small icons on list items indicating if a record has been successfully synced to the central N'Djamena database.

### Police vs. Citizen Differentiation
- **Police Panel:** Uses denser lists with smaller typography and high-contrast borders for data-heavy tasks.
- **Citizen Interface:** Uses larger touch targets, increased whitespace, and instructional icons to guide non-professional users.